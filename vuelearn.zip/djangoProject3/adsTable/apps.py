from django.apps import AppConfig


class AdstableConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "adsTable"
