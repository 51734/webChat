from django.http import JsonResponse, HttpResponse
from rest_framework.views import APIView
from .models import CarInfo, MyViewSet


class MyAPIView(APIView):
    def get(self, request):
        data = {'message': 'Hello, World!'}
        return JsonResponse(data)


class car_info_view(APIView):
    def get(self, request):
        serializer = MyViewSet.serializer_class(MyViewSet.queryset, many=True)
        # 将 CarInfo 模型对象转换为 JSON 数据并返回
        return JsonResponse({'data': serializer.data, 'errorCode': 0})
