from django.db import models

# Create your models here.
from rest_framework import routers, serializers, viewsets


# 定义模型
class CarInfo(models.Model):
    # 车型
    carType = models.CharField(max_length=100)
    # 版本号
    carVersion = models.CharField(max_length=100)
    # 车辆数
    carNum = models.IntegerField()
    # 泊入次数
    parkInNum = models.IntegerField()
    # 泊入成功次数
    parkInSuccess = models.IntegerField()
    # 泊出次数
    parkOutNum = models.IntegerField()
    # 泊出成功次数
    parkOutSuccess = models.IntegerField()
    # 问题数
    eventNum = models.IntegerField()
    # 事故数
    accNum = models.IntegerField()


# 定义序列化器
class MyModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = CarInfo
        fields = '__all__'


# 定义视图集
class MyViewSet(viewsets.ModelViewSet):
    queryset = CarInfo.objects.all()
    serializer_class = MyModelSerializer

