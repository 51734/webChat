import { onMounted, ref } from 'vue'
import * as echarts from 'echarts'

export default {
  setup() {
    const table_data = ref([
      {
        type: '',
        axis: '',
        series: 0
      }
    ])
    const title = ref('柱状图')
    const input_axis = ref('')
    const input_series = ref(0)
    const input_type = ref('')

    const create_axis = () => {
      // 假设你的数据如下：
      var data = [
        {
          车型: 'X1',
          版本号: 'ADS2.0 010',
          车辆数: 10,
          泊入次数: 100,
          泊入成功次数: 90,
          泊出次数: 100,
          泊出成功次数: 95,
          问题数: 5,
          事故数: 0,
          开始时间: '2024-01-01',
          结束时间: '2024-01-31'
        },
        {
          车型: 'X2',
          版本号: 'ADS2.0 110',
          车辆数: 8,
          泊入次数: 80,
          泊入成功次数: 70,
          泊出次数: 80,
          泊出成功次数: 75,
          问题数: 5,
          事故数: 1,
          开始时间: '2024-01-01',
          结束时间: '2024-01-31'
        }
        // 其他数据...
      ]

      // 已知的legend和xAxis
      var legend = ['泊入次数', '泊入成功次数']
      var xAxis = Array.from(
        new Set(
          data.map(function (item) {
            return item.车型
          })
        )
      ) // 使用Set来去重

      // 创建图表
      var chart = echarts.init(document.getElementById('myChart'))

      // 计算series
      var series = legend.flatMap(function (name, index) {
        return [
          {
            name: name,
            type: 'bar',
            data: data.map(function (item) {
              return item[name]
            })
          },
          {
            name: name,
            type: 'line',
            data: data.map(function (item) {
              return item[name]
            })
          }
        ]
      })

      // 使用ECharts的setOption方法来更新图表：
      chart.setOption({
        legend: {
          data: legend
        },
        xAxis: {
          data: xAxis
        },
        yAxis: {},
        series: series
      })

      // const data_xAxis = []
      // const data_series = []
      // for (let i = 0; i < table_data.value.length; i++) {
      //   data_xAxis.push(table_data.value[i].axis)
      //   data_series.push(table_data.value[i].series)
      // }
      // const dom = document.getElementById('myChart')
      // const myChart = echarts.init(dom)
      // const option = {
      //   title: {
      //     text: title.value
      //   },
      //   tooltip: {},
      //   legend: {
      //     data: ['A', 'B']
      //   },
      //   xAxis: {
      //     data: ['V1', 'V2']
      //   },
      //   yAxis: {},
      //   series: [
      //     {
      //       name: 'A',
      //       type: 'bar',
      //       data: [11]
      //     },
      //     {
      //       name: 'B',
      //       type: 'bar',
      //       data: [15]
      //     }
      //   ]
      // }
      // const option = {
      //   title: {
      //     text: title.value
      //   },
      //   tooltip: {},
      //   legend: {
      //     data: ['man','wman']
      //   },
      //   xAxis: {
      //     data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
      //   },
      //   yAxis: {},
      //   series: [
      //     {
      //       name: 'man',
      //       type: 'bar',
      //       data: [23, 24, 18, 25, 27, 28, 25]
      //     },
      //     {
      //       name: 'wman',
      //       type: 'bar',
      //       data: [26, 24, 18, 22, 23, 20, 27]
      //     }
      //   ]
      // }
      myChart.setOption(option)
    }

    const deleteItemByIndex = (row: { axis: string }) => {
      const index = table_data.value.findIndex((item) => item.axis == row.axis)
      table_data.value.splice(index, 1)
      create_axis()
    }

    const insertData = () => {
      let hasType = false
      for (const element of data_legend) {
        if (element.name === input_type.value) {
          hasType = true
          break
        }
      }
      if (!hasType) {
        data_legend.push({ name: input_type.value })
      }
      table_data.value.push({
        type: input_type.value,
        axis: input_axis.value,
        series: input_series.value
      })
      create_axis()
    }

    onMounted(() => {
      create_axis()
    })

    return {
      table_data,
      title,
      input_axis,
      input_series,
      deleteItemByIndex,
      insertData
    }
  }
}
