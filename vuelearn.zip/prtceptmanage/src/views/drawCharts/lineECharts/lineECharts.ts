import { onMounted, ref } from 'vue'
import * as echarts from 'echarts'

export default {
  setup() {
    const table_data = ref([
      {
        xaxis: '',
        yaxis: 0
      }
    ])
    const title = ref('在线绘制折线图')
    const input_xaxis = ref('')
    const input_yaxis = ref(0)

    const create_axis = () => {
      const data_xAxis = []
      const data_yAxis = []
      for (let i = 0; i < table_data.value.length; i++) {
        data_xAxis.push(table_data.value[i].xaxis)
        data_yAxis.push(table_data.value[i].yaxis)
      }
      const dom = document.getElementById('myChart')
      const myChart = echarts.init(dom)
      const option = {
        title: {
          text: title.value
        },
        tooltip: {},
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: data_xAxis
        },
        yAxis: {
          type: 'value'
        },
        legend: {},
        series: [
          {
            name: '示例数据',
            data: data_yAxis,
            type: 'line',
            areaStyle: {},
            label: {
              show: true,
              position: 'top'
            },
            smooth: true
          }
        ]
      }
      myChart.setOption(option)
    }

    const deleteItemByIndex = (row: { xaxis: string }) => {
      const index = table_data.value.findIndex((item) => item.xaxis == row.xaxis)
      table_data.value.splice(index, 1)
      create_axis()
    }

    const insertData = () => {
      table_data.value.push({
        xaxis: input_xaxis.value,
        yaxis: input_yaxis.value
      })
      create_axis()
    }

    onMounted(() => {
      create_axis()
    })

    return {
      table_data,
      title,
      input_xaxis,
      input_yaxis,
      deleteItemByIndex,
      insertData
    }
  }
}
