import { onMounted, ref } from 'vue'
import * as echarts from 'echarts'

export default {
  setup() {
    const pie_data = ref([
      {
        name: '',
        value: 0
      }
    ])
    const title = ref('饼状图')
    const input_name = ref('')
    const input_value = ref(0)

    const create_pie = () => {
      const myChart = echarts.init(document.getElementById('myChart'))
      const option = {
        title: {
          text: title.value
        },
        tooltip: {},
        legend: {
          y: 50,
          textStyle: {
            fontSize: 14
          }
        },
        label: {
          show: true
        },
        series: [
          {
            name: '分布',
            type: 'pie',
            radius: '70%',
            center: ['50%', '60%'],
            label: {
              formatter: function (params: { name: string; value: string }) {
                console.log(params.name + ' ' + params.value + '%')
                return params.name + ' ' + params.value + '%'
              },
              textStyle: {
                fontSize: 14,
                fontWeight: 'bolder'
              },
              color: 'inherit'
            },
            data: pie_data.value,
            selectedMode: 'single',
            selectedOffset: 10
          }
        ]
      }
      myChart.setOption(option)
    }

    const deleteItemByIndex = (row: { name: any }) => {
      const index = pie_data.value.findIndex((item) => item.name == row.name)
      pie_data.value.splice(index, 1)
      create_pie()
    }

    const insertData = () => {
      pie_data.value.push({
        name: input_name.value,
        value: input_value.value
      })
      create_pie()
    }

    onMounted(() => {
      create_pie()
    })

    return {
      pie_data,
      title,
      input_name,
      input_value,
      deleteItemByIndex,
      insertData
    }
  }
}
