<template>
  <my-table
    :table-data="tableData"
    :table-header="tableHeader"
    :typeSelect="typeSelect"
    :axisSelect="axisSelect"
    @handleDelete="handleDelete"
    @handleSave="handleSave"
  />
</template>

<script lang="ts" setup>
// 导入my-table组件
import MyTable from '../components/MyTable.vue'

const tableHeader = ref([
  { prop: 'carType', label: '车型号' },
  { prop: 'carVersion', label: '版本号' },
  { prop: 'carNum', label: '车辆数' },
  { prop: 'parkInNum', label: '泊入次数' },
  { prop: 'parkInSuccess', label: '泊入成功' },
  { prop: 'parkOutNum', label: '泊出次数' },
  { prop: 'parkOutSuccess', label: '泊出成功' },
  { prop: 'eventNum', label: '问题数' },
  { prop: 'accNum', label: '事故数' },
  { prop: 'startTime', label: '开始时间' },
  { prop: 'endTime', label: '截至时间' }
])

const typeSelect = ref([
  { prop: 'carNum', label: '车辆数' },
  { prop: 'parkInNum', label: '泊入次数' },
  { prop: 'parkInSuccess', label: '泊入成功' },
  { prop: 'parkOutNum', label: '泊出次数' },
  { prop: 'parkOutSuccess', label: '泊出成功' },
  { prop: 'eventNum', label: '问题数' },
  { prop: 'accNum', label: '事故数' }
])

const axisSelect = ref([
  { prop: 'carType', label: '车型号' },
  { prop: 'carVersion', label: '版本号' },
  { prop: 'startTime', label: '开始时间' },
  { prop: 'endTime', label: '截至时间' }
])

const tableData = ref([
  {
    carType: 'X1',
    carVersion: 'ADS2.0 010',
    carNum: 10,
    parkInNum: 100,
    parkInSuccess: 90,
    parkOutNum: 100,
    parkOutSuccess: 95,
    eventNum: 5,
    accNum: 3,
    startTime: '2024-01-01',
    endTime: '2024-01-31'
  },
  {
    carType: 'F1',
    carVersion: 'ADS2.0 011',
    carNum: 20,
    parkInNum: 200,
    parkInSuccess: 180,
    parkOutNum: 300,
    parkOutSuccess: 290,
    eventNum: 5,
    accNum: 1,
    startTime: '2024-01-01',
    endTime: '2024-01-31'
  },
  {
    carType: 'E11',
    carVersion: 'ADS2.0 010',
    carNum: 15,
    parkInNum: 150,
    parkInSuccess: 135,
    parkOutNum: 150,
    parkOutSuccess: 95,
    eventNum: 4,
    accNum: 2,
    startTime: '2024-01-01',
    endTime: '2024-01-31'
  }
])

const handleDelete = (row: any) => {
  console.log('delete in')
}

const handleEdit = (row: any) => {
  console.log('edit in')
}

const handleSave = () => {
  console.log('save in')
}

const handleAdd = () => {
  console.log('save in')
}
</script>
