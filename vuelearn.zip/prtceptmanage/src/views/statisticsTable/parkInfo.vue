<template>
  <div style="padding: 10px">
    <el-button type="primary" @click="handleAdd"> 新增 </el-button>
  </div>
  <div>
    <el-table :data="tableData" style="width: 100%" border ref="multipleTableRef">
      <el-table-column type="selection"> </el-table-column>
      <el-table-column
        :prop="item.prop"
        :label="item.label"
        v-for="item in tableHeader"
        :key="item.prop"
      >
        <template #default="scope">
          <el-date-picker
            v-if="item.prop === 'startTime' || item.prop === 'endTime'"
            :disabled="editAbleRow !== scope.$index"
            v-model="scope.row[item.prop]"
            type="date"
          />
          <el-input v-else-if="editAbleRow === scope.$index" v-model="scope.row[item.prop]" />
          <span v-else>{{ scope.row[item.prop] }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          <el-button type="primary" link @click="handleEdit(row)">编辑</el-button>
          <el-button v-if="editAbleRow !== -1" type="primary" link @click="handleSave()"
            >保存</el-button
          >
        </template>
      </el-table-column>
    </el-table>
  </div>
  <div class="container">
    <div class="right-grid">
      <el-row>
        <el-form>
          <el-form-item label="聚类项">
            <el-select
              v-model="selectType"
              class="m-2"
              style="float: right"
              multiple
              collapse-tags
              collapse-tags-tooltip
            >
              <el-option
                v-for="item in typeSelect"
                :key="item.prop"
                :label="item.label"
                :value="item.prop"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="横坐标">
            <el-select v-model="selectAxis" class="m-2" style="float: right">
              <el-option
                v-for="item in axisSelect"
                :key="item.prop"
                :label="item.label"
                :value="item.prop"
            /></el-select>
          </el-form-item>
          <el-form-item label="图表类型">
            <el-select v-model="eChartsType" class="m-2" style="float: right">
              <el-option
                v-for="item in showType"
                :key="item.prop"
                :label="item.label"
                :value="item.prop"
            /></el-select>
          </el-form-item>
          <el-button type="primary" @click="handleCreateEcharts" style="float: right">
            生成图表
          </el-button>
        </el-form>
      </el-row>
    </div>
    <div class="right-grid" id="myChart"></div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import * as echarts from 'echarts'
import type { ElTable } from 'element-plus'

interface ParkInfo {
  carType: string
  carVersion: string
  carNum: number
  parkInNum: number
  parkInSuccess: number
  parkOutNum: number
  parkOutSuccess: number
  eventNum: number
  accNum: number
  startTime: Date
  endTime: Date
}
let editAbleRow = ref(-1)
let selectType = ref([])
let selectAxis = ref('')
let eChartsType = ref('')
const multipleTableRef = ref<InstanceType<typeof ElTable>>()
const multipleSelection = ref<ParkInfo[]>([])
const tableHeader = ref([
  { prop: 'carType', label: '车型号' },
  { prop: 'carVersion', label: '版本号' },
  { prop: 'carNum', label: '车辆数' },
  { prop: 'parkInNum', label: '泊入次数' },
  { prop: 'parkInSuccess', label: '泊入成功' },
  { prop: 'parkOutNum', label: '泊出次数' },
  { prop: 'parkOutSuccess', label: '泊出成功' },
  { prop: 'eventNum', label: '问题数' },
  { prop: 'accNum', label: '事故数' },
  { prop: 'startTime', label: '开始时间' },
  { prop: 'endTime', label: '截至时间' }
])

const typeSelect = ref([
  { prop: 'carNum', label: '车辆数' },
  { prop: 'parkInNum', label: '泊入次数' },
  { prop: 'parkInSuccess', label: '泊入成功' },
  { prop: 'parkOutNum', label: '泊出次数' },
  { prop: 'parkOutSuccess', label: '泊出成功' },
  { prop: 'eventNum', label: '问题数' },
  { prop: 'accNum', label: '事故数' }
])

const axisSelect = ref([
  { prop: 'carType', label: '车型号' },
  { prop: 'carVersion', label: '版本号' },
  { prop: 'startTime', label: '开始时间' },
  { prop: 'endTime', label: '截至时间' }
])

const showType = ref([
  { prop: 'bar', label: '柱状图' },
  { prop: 'line', label: '折线图' }
])

const dictionary = {
  carNum: '车辆数',
  parkInNum: '泊入次数',
  parkInSuccess: '泊入成功',
  parkOutNum: '泊出次数',
  parkOutSuccess: '泊出成功',
  eventNum: '问题数',
  accNum: '事故数'
}

const tableData = ref([
  {
    carType: 'X1',
    carVersion: 'ADS2.0 010',
    carNum: 10,
    parkInNum: 100,
    parkInSuccess: 90,
    parkOutNum: 100,
    parkOutSuccess: 95,
    eventNum: 5,
    accNum: 3,
    startTime: '2024-01-01',
    endTime: '2024-01-31'
  },
  {
    carType: 'F1',
    carVersion: 'ADS2.0 011',
    carNum: 20,
    parkInNum: 200,
    parkInSuccess: 180,
    parkOutNum: 300,
    parkOutSuccess: 290,
    eventNum: 5,
    accNum: 1,
    startTime: '2024-01-01',
    endTime: '2024-01-31'
  },
  {
    carType: 'E11',
    carVersion: 'ADS2.0 010',
    carNum: 15,
    parkInNum: 150,
    parkInSuccess: 135,
    parkOutNum: 150,
    parkOutSuccess: 95,
    eventNum: 4,
    accNum: 2,
    startTime: '2024-01-01',
    endTime: '2024-01-31'
  }
])

const handleDelete = (row: any) => {
  const index = tableData.value.indexOf(row)
  if (index !== -1) {
    tableData.value.splice(index, 1)
  }
}

const handleEdit = (row: any) => {
  editAbleRow.value = tableData.value.indexOf(row)
}

const handleSave = () => {
  editAbleRow.value = -1
}

const handleAdd = () => {
  editAbleRow.value = 0
  tableData.value.unshift({
    carType: '',
    carVersion: '',
    carNum: 0,
    parkInNum: 0,
    parkInSuccess: 0,
    parkOutNum: 0,
    parkOutSuccess: 0,
    eventNum: 0,
    accNum: 0,
    startTime: '',
    endTime: ''
  })
}
var myChart: echarts.ECharts
const handleCreateEcharts = () => {
  multipleSelection.value = multipleTableRef.value!.getSelectionRows()
  const legend_data = selectType.value.map((item) => dictionary[item])
  const xAxis = Array.from(new Set(multipleSelection.value.map((item) => item[selectAxis.value])))
  let ySeries = selectType.value.flatMap(function (name) {
    const axisDate = xAxis.map(function (x) {
      // 对于每一个x轴的值，我们找到所有具有相同车型的项，然后将它们的值相加
      var items = multipleSelection.value.filter(function (item) {
        return item[selectAxis.value] === x
      })
      return items.reduce(function (sum, item) {
        return sum + (item[name] || 0)
      }, 0)
    })
    return [
      {
        name: dictionary[name],
        type: eChartsType.value,
        data: axisDate
      }
    ]
  })
  const dom = document.getElementById('myChart')
  if (myChart != null && myChart != undefined) {
    myChart.dispose()
  }
  myChart = echarts.init(dom)
  const option = {
    tooltip: {},
    legend: {
      data: legend_data
    },
    xAxis: {
      data: xAxis
    },
    yAxis: {},
    series: ySeries
  }
  myChart.setOption(option)
}

onMounted(() => {
  handleCreateEcharts()
})
</script>

<style scoped>
.container {
  display: grid;
  grid-template-columns: 20% 80%;
  width: 80vw;
  height: 100vh;
}

.left-grid {
  border-radius: 2%;
  padding: 20px;
}

.right-grid {
  border-radius: 2%;
  padding: 20px;
  height: 50%;
}
</style>
