<template>
  <div style="padding: 10px">
    <el-button type="primary" @click="handleAdd"> 新增 </el-button>
  </div>
  <div>
    <el-table :data="tableData" style="width: 100%" border ref="multipleTableRef">
      <el-table-column type="selection"> </el-table-column>
      <el-table-column
        :prop="item.prop"
        :label="item.label"
        v-for="item in tableHeader"
        :key="item.prop"
      >
        <template #default="scope">
          <el-date-picker
            v-if="item.prop === 'startTime' || item.prop === 'endTime'"
            :disabled="editAbleRow !== scope.$index"
            v-model="scope.row[item.prop]"
            type="date"
          />
          <el-input v-else-if="editAbleRow === scope.$index" v-model="scope.row[item.prop]" />
          <span v-else>{{ scope.row[item.prop] }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          <el-button type="primary" link @click="handleEdit(row)">编辑</el-button>
          <el-button v-if="editAbleRow !== -1" type="primary" link @click="handleSave()"
            >保存</el-button
          >
        </template>
      </el-table-column>
    </el-table>
  </div>
  <div class="container">
    <div class="right-grid">
      <el-row>
        <el-form>
          <el-form-item label="聚类项">
            <el-select
              v-model="selectType"
              class="m-2"
              style="float: right"
              multiple
              collapse-tags
              collapse-tags-tooltip
            >
              <el-option
                v-for="item in typeSelect"
                :key="item.prop"
                :label="item.label"
                :value="item.prop"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="横坐标">
            <el-select v-model="selectAxis" class="m-2" style="float: right">
              <el-option
                v-for="item in axisSelect"
                :key="item.prop"
                :label="item.label"
                :value="item.prop"
            /></el-select>
          </el-form-item>
          <el-form-item label="图表类型">
            <el-select v-model="eChartsType" class="m-2" style="float: right">
              <el-option
                v-for="item in showType"
                :key="item.prop"
                :label="item.label"
                :value="item.prop"
            /></el-select>
          </el-form-item>
          <el-button type="primary" @click="handleCreateEcharts" style="float: right">
            生成图表
          </el-button>
        </el-form>
      </el-row>
    </div>
    <div class="right-grid" id="myChart"></div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import * as echarts from 'echarts'
import type { ElTable } from 'element-plus'
const props = defineProps(['interface', 'tableData', 'tableHeader', 'typeSelect', 'axisSelect'])
const emit = defineEmits(['handleDelete', 'handleSave'])

let editAbleRow = ref(-1)
let selectType = ref([])
let selectAxis = ref('')
let eChartsType = ref('')
const multipleTableRef = ref<InstanceType<typeof ElTable>>()
const multipleSelection = ref([])

const showType = ref([
  { prop: 'bar', label: '柱状图' },
  { prop: 'line', label: '折线图' }
])

const dictionary = {
  carNum: '车辆数',
  parkInNum: '泊入次数',
  parkInSuccess: '泊入成功',
  parkOutNum: '泊出次数',
  parkOutSuccess: '泊出成功',
  eventNum: '问题数',
  accNum: '事故数',
  carReversNum: '倒车次数',
  carTotalNum: '总车辆数'
}
const handleDelete = (row: any) => {
  const index = props.tableData.indexOf(row)
  if (index !== -1) {
    props.tableData.splice(index, 1)
    emit('handleDelete')
  }
}

const handleEdit = (row: any) => {
  editAbleRow.value = props.tableData.indexOf(row)
}

const handleSave = () => {
  editAbleRow.value = -1
  emit('handleSave')
}

const handleAdd = () => {
  editAbleRow.value = 0
  props.tableData.unshift({
    carType: '',
    carVersion: '',
    carNum: 0,
    parkInNum: 0,
    parkInSuccess: 0,
    parkOutNum: 0,
    parkOutSuccess: 0,
    eventNum: 0,
    accNum: 0,
    startTime: '',
    endTime: ''
  })
}
var myChart: echarts.ECharts
const handleCreateEcharts = () => {
  multipleSelection.value = multipleTableRef.value!.getSelectionRows()
  const legend_data = selectType.value.map((item) => dictionary[item])
  const xAxis = Array.from(new Set(multipleSelection.value.map((item) => item[selectAxis.value])))
  let ySeries = selectType.value.flatMap(function (name) {
    const axisDate = xAxis.map(function (x) {
      // 对于每一个x轴的值，我们找到所有具有相同车型的项，然后将它们的值相加
      var items = multipleSelection.value.filter(function (item) {
        return item[selectAxis.value] === x
      })
      return items.reduce(function (sum, item) {
        return sum + (item[name] || 0)
      }, 0)
    })
    return [
      {
        name: dictionary[name],
        type: eChartsType.value,
        data: axisDate
      }
    ]
  })
  const dom = document.getElementById('myChart')
  if (myChart != null && myChart != undefined) {
    myChart.dispose()
  }
  myChart = echarts.init(dom)
  const option = {
    tooltip: {},
    legend: {
      data: legend_data
    },
    xAxis: {
      data: xAxis
    },
    yAxis: {},
    series: ySeries
  }
  myChart.setOption(option)
}

onMounted(() => {
  handleCreateEcharts()
})
</script>

<style scoped>
.container {
  display: grid;
  grid-template-columns: 20% 80%;
  width: 80vw;
  height: 100vh;
}

.left-grid {
  border-radius: 2%;
  padding: 20px;
}

.right-grid {
  border-radius: 2%;
  padding: 20px;
  height: 50%;
}
</style>
