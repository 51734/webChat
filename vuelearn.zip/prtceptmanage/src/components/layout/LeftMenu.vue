<template>
  <el-row>
    <el-col>
      <el-menu
        active-text-color="#ffd04b"
        background-color="#545c64"
        class="el-menu-vertical-demo"
        default-active="1"
        text-color="#fff"
        router
        style="height: 90vh"
      >
        <el-sub-menu index="1">
          <template #title>
            <el-icon><icon-menu /></el-icon>
            <span>统计图绘制</span>
          </template>
          <el-menu-item index="/table/parkTable">泊车数据统计</el-menu-item>
          <el-menu-item index="/table/reversTable">倒车数统计</el-menu-item>
          <el-menu-item index="/table/carNumTable">车辆数统计</el-menu-item>
        </el-sub-menu>
      </el-menu>
    </el-col>
  </el-row>
</template>

<script lang="ts" setup>
import { Menu as IconMenu } from '@element-plus/icons-vue'
</script>
