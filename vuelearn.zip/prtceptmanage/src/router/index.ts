import { createRouter, createWebHistory } from 'vue-router'
import parkTable from '../views/perceptionTable/parkTable.vue'
import reversTable from '../views/perceptionTable/reversTable.vue'
import carNumTable from '../views/perceptionTable/carNumTable.vue'
import parkInfo from '../views/statisticsTable/parkInfo.vue'
import test from '../views/test.vue'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/table/parkTable',
      name: 'car part',
      component: parkTable
    },
    {
      path: '/table/reversTable',
      name: 'car revers',
      component: reversTable
    },
    {
      path: '/table/carNumTable',
      name: 'car number',
      component: carNumTable
    }
  ]
})

export default router
